module swap intel gcc
module load mpi/gcc_openmpi
