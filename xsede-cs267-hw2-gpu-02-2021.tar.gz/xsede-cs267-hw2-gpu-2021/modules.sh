module load cuda
